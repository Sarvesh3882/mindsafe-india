## Packages
leaflet | For interactive maps
react-leaflet | React components for Leaflet maps
recharts | For impact analytics charts and data visualization
framer-motion | For beautiful page transitions and animations
lucide-react | Icon set (already in base, but ensuring)
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'Fira Code'", "monospace"],
}
