import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useImpact() {
  return useQuery({
    queryKey: [api.impact.get.path],
    queryFn: async () => {
      const res = await fetch(api.impact.get.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch impact stats");
      return api.impact.get.responses[200].parse(await res.json());
    },
  });
}
