import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  color?: "primary" | "blue" | "orange";
}

export function StatCard({ label, value, icon: Icon, trend, color = "primary" }: StatCardProps) {
  const colorMap = {
    primary: "text-primary bg-primary/10",
    blue: "text-blue-600 bg-blue-100",
    orange: "text-orange-600 bg-orange-100",
  };

  return (
    <div className="bg-card hover:shadow-lg transition-shadow duration-300 rounded-xl p-6 border border-border/50">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{label}</p>
          <h3 className="text-2xl font-bold font-display text-foreground">{value}</h3>
          {trend && (
            <p className="text-xs font-medium text-primary mt-1 flex items-center gap-1">
              {trend}
            </p>
          )}
        </div>
        <div className={cn("p-3 rounded-xl", colorMap[color])}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}
