import { motion } from "framer-motion";
import { ExternalLink, Play, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";

const SIMULATION_URL = "https://26e892a4-407a-4682-8b95-5dcbf02a9d56-00-18mwmpaarb385.spock.replit.dev/";

export default function Simulation() {
  const [isLoading, setIsLoading] = useState(true);
  const [key, setKey] = useState(0);

  const handleRefresh = () => {
    setIsLoading(true);
    setKey(prev => prev + 1);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto px-4 py-8"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">
            Data Wiping Simulation
          </h1>
          <p className="text-muted-foreground mt-1">
            Interactive simulation of our secure data destruction process
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleRefresh}
            data-testid="button-refresh-simulation"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button
            variant="outline"
            onClick={() => window.open(SIMULATION_URL, "_blank")}
            data-testid="button-open-fullscreen"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Open Fullscreen
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Play className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">Live Simulation Environment</CardTitle>
              <CardDescription>
                See how our military-grade data wiping works in real-time
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0 relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 z-10">
              <div className="flex flex-col items-center gap-3">
                <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm text-muted-foreground">Loading simulation...</p>
              </div>
            </div>
          )}
          <iframe
            key={key}
            src={SIMULATION_URL}
            className="w-full border-0"
            style={{ height: "calc(100vh - 280px)", minHeight: "500px" }}
            onLoad={() => setIsLoading(false)}
            title="Data Wiping Simulation"
            data-testid="iframe-simulation"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
          />
        </CardContent>
      </Card>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-2">Military-Grade Wiping</h3>
            <p className="text-sm text-muted-foreground">
              Uses DoD 5220.22-M standard for complete data destruction
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-2">Verification Process</h3>
            <p className="text-sm text-muted-foreground">
              Multiple pass verification ensures zero data recovery possibility
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-2">Certificate Generation</h3>
            <p className="text-sm text-muted-foreground">
              Cryptographic QR certificate for compliance and audit trails
            </p>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
