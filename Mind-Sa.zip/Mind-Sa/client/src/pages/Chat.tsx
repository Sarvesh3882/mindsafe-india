import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { MessageSquare, Send, Bot, User, Leaf } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

// Full page chat version of the widget
export default function Chat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<{role: 'user'|'model', content: string}[]>([
    { role: 'model', content: `Hello ${user?.firstName || 'there'}! I'm your Mind-Safe eco-assistant. I can help you with recycling guidelines, scheduling pickups, or understanding your environmental impact.` }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const res = await fetch(`/api/conversations/1/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: userMsg }),
      });

      if (!res.ok) throw new Error('Failed to send');

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let botResponse = "";
      
      setMessages(prev => [...prev, { role: 'model', content: "" }]);

      while (true) {
        const { done, value } = await reader!.read();
        if (done) break;
        
        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = JSON.parse(line.slice(6));
            if (data.content) {
              botResponse += data.content;
              setMessages(prev => {
                const newMsgs = [...prev];
                newMsgs[newMsgs.length - 1].content = botResponse;
                return newMsgs;
              });
            }
          }
        }
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', content: "Sorry, I'm having trouble connecting right now." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 h-[calc(100vh-64px)] flex flex-col gap-4">
      <div className="text-center mb-4">
        <h1 className="text-2xl font-bold font-display flex items-center justify-center gap-2">
          <Leaf className="w-6 h-6 text-primary" /> AI Recycling Assistant
        </h1>
        <p className="text-muted-foreground">Ask anything about e-waste disposal.</p>
      </div>

      <Card className="flex-1 flex flex-col overflow-hidden shadow-xl border-primary/10 max-w-4xl mx-auto w-full">
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-muted/20" ref={scrollRef}>
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 fade-in duration-300`}>
              <div className={`max-w-[80%] md:max-w-[70%] rounded-2xl px-6 py-4 shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-tr-none' 
                  : 'bg-white dark:bg-card text-foreground rounded-tl-none border border-border'
              }`}>
                <div className="flex items-center gap-2 mb-1 opacity-70 text-xs font-bold uppercase tracking-wider">
                  {msg.role === 'user' ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
                  {msg.role === 'user' ? 'You' : 'EcoBot'}
                </div>
                <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white dark:bg-card rounded-2xl px-6 py-4 rounded-tl-none border border-border flex gap-1 items-center">
                <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></span>
                <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></span>
                <span className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></span>
              </div>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-4 bg-background border-t flex gap-3">
          <Input 
            value={input} 
            onChange={e => setInput(e.target.value)}
            placeholder="Type your question..."
            className="h-12 rounded-full px-6 shadow-inner"
            disabled={isLoading}
            autoFocus
          />
          <Button type="submit" size="icon" className="h-12 w-12 rounded-full shrink-0 shadow-lg shadow-primary/20" disabled={isLoading || !input.trim()}>
            <Send className="w-5 h-5" />
          </Button>
        </form>
      </Card>
    </div>
  );
}
