import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Recycle, Truck, ArrowRight, Leaf } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background font-body">
      {/* Header */}
      <header className="fixed w-full top-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Leaf className="w-6 h-6 text-primary" />
            </div>
            <span className="text-xl font-bold font-display">Mind-Safe<span className="text-primary">India</span></span>
          </div>
          <div className="flex gap-4">
            <Link href="/api/login">
              <Button variant="ghost">Log In</Button>
            </Link>
            <Link href="/api/login">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent -z-10" />
        
        <div className="container mx-auto px-4 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-in slide-in-from-left duration-700 fade-in">
            <h1 className="text-5xl md:text-6xl font-display font-bold leading-[1.1] text-foreground">
              Secure E-Waste Management for a <span className="text-primary">Greener Future</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg">
              We provide secure, certified e-waste disposal with on-site data wiping and real-time tracking. Turn your old electronics into environmental impact.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/api/login">
                <Button size="lg" className="h-12 px-8 text-lg rounded-full shadow-lg shadow-primary/20">
                  Schedule Pickup <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/api/login">
                <Button size="lg" variant="outline" className="h-12 px-8 text-lg rounded-full">
                  For Businesses
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="relative animate-in slide-in-from-right duration-700 fade-in delay-200">
            {/* Abstract Decorative Elements */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px] -z-10" />
            
            <div className="relative z-10 grid gap-6">
              {/* Feature Cards as Hero Image */}
              <div className="bg-white dark:bg-card p-6 rounded-2xl shadow-xl border border-border/50 rotate-[-3deg] translate-y-4 hover:rotate-0 transition-transform duration-500">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-green-100 text-green-700 rounded-xl">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">DoD Standard Wiping</h3>
                    <p className="text-sm text-muted-foreground">Certified data destruction</p>
                  </div>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full w-3/4 bg-green-500 rounded-full" />
                </div>
              </div>

              <div className="bg-white dark:bg-card p-6 rounded-2xl shadow-xl border border-border/50 rotate-[2deg] translate-x-8 hover:rotate-0 transition-transform duration-500">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-blue-100 text-blue-700 rounded-xl">
                    <Recycle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Eco-Impact Tracking</h3>
                    <p className="text-sm text-muted-foreground">Real-time sustainability metrics</p>
                  </div>
                </div>
                <div className="flex gap-4 text-center">
                  <div>
                    <div className="font-bold text-xl">24kg</div>
                    <div className="text-xs text-muted-foreground">CO2 Saved</div>
                  </div>
                  <div>
                    <div className="font-bold text-xl">12</div>
                    <div className="text-xs text-muted-foreground">Devices</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-display font-bold mb-4">Why Choose Mind-Safe?</h2>
            <p className="text-muted-foreground">We combine advanced technology with environmental responsibility to offer a seamless recycling experience.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: ShieldCheck,
                title: "100% Data Security",
                desc: "Military-grade data wiping performed on-site before devices leave your premises."
              },
              {
                icon: Truck,
                title: "Doorstep Pickup",
                desc: "Professional logistics team handles packaging and transport securely."
              },
              {
                icon: Recycle,
                title: "Certified Recycling",
                desc: "We ensure zero landfill policy with authorized recycling partners."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-background p-8 rounded-2xl border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center mb-6">
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2">
              <Leaf className="w-6 h-6 text-primary" />
              <span className="text-xl font-bold font-display">Mind-Safe India</span>
            </div>
            <p className="text-sm text-background/60">
              © 2024 Mind-Safe India. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
