import { useOrders } from "@/hooks/use-orders";
import { useImpact } from "@/hooks/use-impact";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/StatCard";
import { Link } from "wouter";
import { Leaf, Recycle, Droplets, Plus, ArrowRight, Clock, CheckCircle2, Truck } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: orders, isLoading: ordersLoading } = useOrders();
  const { data: impact, isLoading: impactLoading } = useImpact();

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  const activeOrders = orders?.filter(o => o.status !== 'completed') || [];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8 animate-in fade-in duration-500">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold">Welcome back, {user?.firstName}!</h1>
          <p className="text-muted-foreground">Here's your environmental impact overview.</p>
        </div>
        <Link href="/pickup">
          <Button className="rounded-full shadow-lg shadow-primary/25">
            <Plus className="w-4 h-4 mr-2" /> Schedule Pickup
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard
          label="CO2 Emissions Saved"
          value={`${(impact?.co2Saved || 0) / 1000} kg`}
          icon={Leaf}
          color="primary"
          trend="+12% this month"
        />
        <StatCard
          label="E-Waste Recycled"
          value={`${(impact?.eWasteRecycled || 0) / 1000} kg`}
          icon={Recycle}
          color="orange"
          trend="3 devices processed"
        />
        <StatCard
          label="Water Saved"
          value={`${impact?.waterSaved || 0} L`}
          icon={Droplets}
          color="blue"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Active Orders */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-display font-bold">Active Orders</h2>
          </div>

          <div className="space-y-4">
            {ordersLoading ? (
              <div className="p-8 text-center text-muted-foreground bg-card rounded-xl border border-dashed">
                Loading orders...
              </div>
            ) : activeOrders.length === 0 ? (
              <div className="p-12 text-center bg-card rounded-xl border border-dashed space-y-4">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                  <Recycle className="w-8 h-8 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">No active pickups</h3>
                  <p className="text-muted-foreground">Schedule a pickup to start recycling.</p>
                </div>
                <Link href="/pickup">
                  <Button variant="outline">Schedule Now</Button>
                </Link>
              </div>
            ) : (
              activeOrders.map((order) => (
                <div key={order.id} className="bg-card p-6 rounded-xl border border-border/50 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-lg">Order #{order.id}</span>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(order.status)}`}>
                          {order.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground flex items-center gap-2">
                        <Clock className="w-4 h-4" /> 
                        Scheduled: {order.scheduledDate ? format(new Date(order.scheduledDate), 'PPP') : 'Pending'}
                      </p>
                      <p className="text-sm text-muted-foreground">{order.pickupAddress}</p>
                    </div>
                    
                    <Link href={`/tracking/${order.id}`}>
                      <Button variant="outline" className="w-full md:w-auto">
                        Track Status <ArrowRight className="ml-2 w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Tips / Sidebar */}
        <div className="space-y-6">
          <h2 className="text-xl font-display font-bold">Recycling Guide</h2>
          <div className="bg-primary/5 p-6 rounded-2xl border border-primary/10 space-y-4">
            <h3 className="font-bold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" />
              Before Pickup
            </h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex gap-2">
                <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 shrink-0" />
                Back up all your important data to the cloud.
              </li>
              <li className="flex gap-2">
                <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 shrink-0" />
                Sign out of all accounts (iCloud, Google, etc).
              </li>
              <li className="flex gap-2">
                <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 shrink-0" />
                Remove SIM cards and SD cards.
              </li>
              <li className="flex gap-2">
                <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 shrink-0" />
                Keep chargers/accessories bundled if available.
              </li>
            </ul>
            <Link href="/chat">
              <Button variant="link" className="px-0 text-primary">
                Ask AI Assistant for help &rarr;
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
