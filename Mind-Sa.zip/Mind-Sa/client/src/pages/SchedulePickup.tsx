import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateOrder } from "@/hooks/use-orders";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, Smartphone, Laptop, HardDrive, Monitor } from "lucide-react";
import { useLocation } from "wouter";

const deviceSchema = z.object({
  type: z.string().min(1, "Device type is required"),
  model: z.string().min(1, "Model is required"),
  condition: z.string().min(1, "Condition is required"),
});

const formSchema = z.object({
  address: z.string().min(5, "Address is required"),
  scheduledDate: z.string().optional(),
  devices: z.array(deviceSchema).min(1, "Add at least one device"),
});

type FormData = z.infer<typeof formSchema>;

export default function SchedulePickup() {
  const [, setLocation] = useLocation();
  const createOrder = useCreateOrder();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      address: "",
      devices: [{ type: "laptop", model: "", condition: "working" }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "devices",
  });

  const onSubmit = (data: FormData) => {
    createOrder.mutate(data, {
      onSuccess: () => setLocation("/"),
    });
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'phone': return Smartphone;
      case 'laptop': return Laptop;
      case 'desktop': return Monitor;
      default: return HardDrive;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold mb-2">Schedule a Pickup</h1>
        <p className="text-muted-foreground">Tell us what you're recycling and where to collect it.</p>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        {/* Location Section */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold font-display">1. Pickup Location</h2>
          <Card className="p-6">
            <div className="space-y-2">
              <Label htmlFor="address">Full Address</Label>
              <Input 
                id="address" 
                placeholder="Enter your street address, city, pincode" 
                {...form.register("address")}
                className="h-12"
              />
              {form.formState.errors.address && (
                <p className="text-sm text-destructive">{form.formState.errors.address.message}</p>
              )}
            </div>
            
            <div className="mt-4 space-y-2">
              <Label htmlFor="date">Preferred Date (Optional)</Label>
              <Input 
                id="date" 
                type="date"
                {...form.register("scheduledDate")}
                className="h-12 w-full md:w-1/2"
              />
            </div>
          </Card>
        </section>

        {/* Devices Section */}
        <section className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold font-display">2. Devices</h2>
            <Button 
              type="button" 
              variant="outline" 
              size="sm" 
              onClick={() => append({ type: "phone", model: "", condition: "working" })}
            >
              <Plus className="w-4 h-4 mr-2" /> Add Device
            </Button>
          </div>

          <div className="space-y-4">
            {fields.map((field, index) => {
              const currentType = form.watch(`devices.${index}.type`);
              const Icon = getIcon(currentType);

              return (
                <Card key={field.id} className="p-6 relative group overflow-hidden border-l-4 border-l-primary">
                  <div className="absolute top-0 right-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      className="text-muted-foreground hover:text-destructive"
                      onClick={() => remove(index)}
                      disabled={fields.length === 1}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 items-end">
                    <div className="space-y-2">
                      <Label>Device Type</Label>
                      <div className="relative">
                        <Icon className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <select 
                          {...form.register(`devices.${index}.type`)}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 pl-9 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <option value="laptop">Laptop</option>
                          <option value="phone">Smartphone</option>
                          <option value="tablet">Tablet</option>
                          <option value="desktop">Desktop PC</option>
                          <option value="accessory">Accessory/Other</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Model / Description</Label>
                      <Input 
                        placeholder="e.g. MacBook Pro 2019" 
                        {...form.register(`devices.${index}.model`)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Condition</Label>
                      <select 
                        {...form.register(`devices.${index}.condition`)}
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="working">Working</option>
                        <option value="damaged">Damaged Screen/Body</option>
                        <option value="dead">Not Turning On</option>
                        <option value="old">Very Old / Obsolete</option>
                      </select>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
          {form.formState.errors.devices && (
            <p className="text-sm text-destructive">{form.formState.errors.devices.message}</p>
          )}
        </section>

        <div className="flex justify-end pt-4">
          <Button 
            type="submit" 
            size="lg" 
            className="w-full md:w-auto px-8 rounded-full text-lg shadow-lg shadow-primary/20"
            disabled={createOrder.isPending}
          >
            {createOrder.isPending ? "Scheduling..." : "Confirm Pickup"}
          </Button>
        </div>
      </form>
    </div>
  );
}
