import { useOrder } from "@/hooks/use-orders";
import { useRoute } from "wouter";
import { Loader2, CheckCircle2, Circle, Truck, ShieldCheck, Check } from "lucide-react";
import Map from "@/components/Map";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const STEPS = [
  { id: 'pending', label: 'Order Placed', desc: 'Waiting for technician assignment' },
  { id: 'assigned', label: 'Technician Assigned', desc: 'Ramesh is on the way' },
  { id: 'in_progress', label: 'Pickup & Wiping', desc: 'Device collection and on-site wiping' },
  { id: 'verified', label: 'Verified', desc: 'Data destruction certificate generated' },
  { id: 'completed', label: 'Completed', desc: 'Recycling process initiated' },
];

export default function OrderTracking() {
  const [, params] = useRoute("/tracking/:id");
  const orderId = parseInt(params?.id || "0");
  const { data: order, isLoading } = useOrder(orderId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!order) {
    return <div className="container mx-auto p-8 text-center">Order not found</div>;
  }

  const currentStepIndex = STEPS.findIndex(s => s.id === order.status);
  
  // Mock positions for demo
  const userPos: [number, number] = [12.9716, 77.5946]; // Bangalore
  // Mock tech position slightly offset if active
  const techPos: [number, number] | undefined = 
    ['assigned', 'in_progress'].includes(order.status) 
    ? [12.9756, 77.6046] 
    : undefined;

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <h1 className="text-3xl font-display font-bold">Tracking Order #{order.id}</h1>
          <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-bold uppercase">
            {order.status.replace('_', ' ')}
          </span>
        </div>
        <p className="text-muted-foreground">Pickup at: {order.pickupAddress}</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: Status Timeline */}
        <div className="lg:col-span-1 space-y-8">
          <Card className="p-6">
            <h3 className="font-bold font-display mb-6">Progress</h3>
            <div className="relative space-y-8 pl-2">
              {/* Vertical line */}
              <div className="absolute left-[15px] top-2 bottom-2 w-0.5 bg-border -z-10" />
              
              {STEPS.map((step, index) => {
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;
                
                return (
                  <div key={step.id} className="flex gap-4 items-start relative">
                    <div className={cn(
                      "w-7 h-7 rounded-full flex items-center justify-center shrink-0 border-2 bg-background z-10 transition-colors duration-300",
                      isCompleted ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/30 text-muted-foreground"
                    )}>
                      {isCompleted ? <Check className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
                    </div>
                    <div>
                      <h4 className={cn("font-bold text-sm", isCompleted ? "text-foreground" : "text-muted-foreground")}>
                        {step.label}
                      </h4>
                      <p className="text-xs text-muted-foreground">{step.desc}</p>
                      
                      {isCurrent && order.status === 'in_progress' && (
                        <div className="mt-2 p-3 bg-muted/50 rounded-lg border border-border">
                          <div className="flex items-center gap-2 text-xs font-mono text-primary mb-1">
                            <ShieldCheck className="w-3 h-3" />
                            <span>Wiping Sector 0x4A...</span>
                          </div>
                          <div className="h-1.5 w-full bg-background rounded-full overflow-hidden">
                            <div className="h-full bg-primary animate-[width_2s_ease-in-out_infinite] w-[60%]" />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Technician Info */}
          {['assigned', 'in_progress'].includes(order.status) && (
            <Card className="p-6 bg-primary/5 border-primary/20">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                  <Truck className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold">Technician Arriving</h3>
                  <p className="text-sm text-muted-foreground">Ramesh Kumar • 4.8 ★</p>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Right Column: Map & Details */}
        <div className="lg:col-span-2 space-y-6">
          <Map userPos={userPos} techPos={techPos} />
          
          <Card className="p-6">
            <h3 className="font-bold font-display mb-4">Device Details</h3>
            <div className="divide-y">
              {order.devices.map((device, i) => (
                <div key={i} className="py-3 flex justify-between items-center first:pt-0 last:pb-0">
                  <div>
                    <p className="font-medium">{device.type} - {device.model}</p>
                    <p className="text-sm text-muted-foreground capitalize">Condition: {device.condition}</p>
                  </div>
                  {order.status === 'verified' && (
                    <span className="flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded">
                      <ShieldCheck className="w-3 h-3" /> Wiped
                    </span>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
