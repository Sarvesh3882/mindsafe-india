import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Import Auth and Chat models from blueprints
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  status: text("status").notNull().default("pending"), // pending, assigned, in_progress, wiped, verified, completed
  technicianName: text("technician_name"),
  technicianId: text("technician_id"),
  pickupAddress: text("pickup_address").notNull(),
  scheduledDate: timestamp("scheduled_date"),
  latitude: text("latitude"), // For mock map
  longitude: text("longitude"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id),
  type: text("type").notNull(), // laptop, phone, etc.
  model: text("model"),
  serialNumber: text("serial_number"),
  condition: text("condition"),
  estimatedValue: integer("estimated_value").default(0),
  disposalMethod: text("disposal_method"), // resale, recycle, reuse
  wipingStatus: text("wiping_status").default("pending"),
});

export const impactStats = pgTable("impact_stats", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  co2Saved: integer("co2_saved").default(0),
  eWasteRecycled: integer("ewaste_recycled").default(0), // in grams
  waterSaved: integer("water_saved").default(0),
});

export const ordersRelations = relations(orders, ({ many }) => ({
  devices: many(devices),
}));

export const devicesRelations = relations(devices, ({ one }) => ({
  order: one(orders, {
    fields: [devices.orderId],
    references: [orders.id],
  }),
}));

export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, createdAt: true, userId: true, status: true });
export const insertDeviceSchema = createInsertSchema(devices).omit({ id: true, orderId: true });

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type ImpactStats = typeof impactStats.$inferSelect;
