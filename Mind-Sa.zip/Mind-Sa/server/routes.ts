import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth } from "./replit_integrations/auth";
import { registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);
  registerImageRoutes(app);

  // Orders API
  app.get(api.orders.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const orders = await storage.getOrders(userId);
    res.json(orders);
  });

  app.post(api.orders.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    try {
      const input = api.orders.create.input.parse(req.body);
      const { devices, scheduledDate, ...restOrderData } = input;
      const orderData = {
        ...restOrderData,
        scheduledDate: scheduledDate ? new Date(scheduledDate) : undefined,
      };
      const order = await storage.createOrder(userId, orderData, devices);
      
      // Seed some impact data if this is the first order (for demo purposes)
      const currentStats = await storage.getImpactStats(userId);
      if (!currentStats) {
        await storage.createOrUpdateImpact(userId, {
            co2Saved: 15, // Mock value
            eWasteRecycled: 500, // 500g
            waterSaved: 100 // 100L
        });
      }

      res.status(201).json(order);
    } catch (err) {
        if (err instanceof z.ZodError) {
          res.status(400).json({ message: err.errors[0].message });
        } else {
          console.error(err);
          res.status(500).json({ message: "Internal Server Error" });
        }
    }
  });

  app.get(api.orders.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const order = await storage.getOrder(Number(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });
    // In a real app, verify user owns order
    res.json(order);
  });

  // Impact API
  app.get(api.impact.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const stats = await storage.getImpactStats(userId) || { co2Saved: 0, eWasteRecycled: 0, waterSaved: 0 };
    res.json(stats);
  });

  return httpServer;
}
