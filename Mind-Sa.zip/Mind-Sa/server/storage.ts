import { db } from "./db";
import { orders, devices, impactStats, type InsertOrder, type InsertDevice, type Order, type Device, type ImpactStats } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Orders
  getOrders(userId: string): Promise<Order[]>;
  getOrder(id: number): Promise<(Order & { devices: Device[] }) | undefined>;
  createOrder(userId: string, order: Partial<InsertOrder> & { pickupAddress: string; scheduledDate?: Date }, devices: InsertDevice[]): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order>;

  // Impact
  getImpactStats(userId: string): Promise<ImpactStats | undefined>;
  createOrUpdateImpact(userId: string, stats: Partial<ImpactStats>): Promise<ImpactStats>;
}

export class DatabaseStorage implements IStorage {
  async getOrders(userId: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.userId, userId));
  }

  async getOrder(id: number): Promise<(Order & { devices: Device[] }) | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;
    const orderDevices = await db.select().from(devices).where(eq(devices.orderId, id));
    return { ...order, devices: orderDevices };
  }

  async createOrder(userId: string, orderData: Partial<InsertOrder> & { pickupAddress: string; scheduledDate?: Date }, devicesData: InsertDevice[]): Promise<Order> {
    const [order] = await db.insert(orders).values({ 
      pickupAddress: orderData.pickupAddress,
      scheduledDate: orderData.scheduledDate,
      userId 
    }).returning();
    if (devicesData.length > 0) {
      await db.insert(devices).values(devicesData.map(d => ({ ...d, orderId: order.id })));
    }
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const [order] = await db.update(orders).set({ status }).where(eq(orders.id, id)).returning();
    return order;
  }

  async getImpactStats(userId: string): Promise<ImpactStats | undefined> {
    const [stats] = await db.select().from(impactStats).where(eq(impactStats.userId, userId));
    return stats;
  }

  async createOrUpdateImpact(userId: string, stats: Partial<ImpactStats>): Promise<ImpactStats> {
    const existing = await this.getImpactStats(userId);
    if (existing) {
      const [updated] = await db.update(impactStats).set(stats).where(eq(impactStats.userId, userId)).returning();
      return updated;
    } else {
      const [created] = await db.insert(impactStats).values({ userId, ...stats }).returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
